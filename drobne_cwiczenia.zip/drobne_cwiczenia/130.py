a = [3, 5, 7]
b = ','.join([str(i) for i in a])
print(b)

