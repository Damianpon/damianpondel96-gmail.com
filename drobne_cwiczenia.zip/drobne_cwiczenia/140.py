c = ";".join(['ala', 'bartek', 'czarek']).upper().center(21, '-')
print(c)
