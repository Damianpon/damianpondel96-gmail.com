a = [3, 5, 7]
print(a)