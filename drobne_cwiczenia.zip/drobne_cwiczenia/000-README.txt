Zastanów się, jaki będzie wynik działania tych programów. A potem sprawdź, czy miałeś rację. Niektóre z programów rzucają błąd - to jest celowe. W takim przypadku powinieneś przewidzieć, że program rzuci błąd.

