a = "abc\ndefg\tghi\njkmlp\tlpo"
print(a)
