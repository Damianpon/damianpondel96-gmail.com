a = [len(str(i)) for i in range(100)]
print(a)

