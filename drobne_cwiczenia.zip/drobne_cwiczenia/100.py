a = '.'.join(['a', 'b'])
b = a.join(['a', 'b'])
print(b)

