a = [3, 5, 7]
b = ','.join(a)
print(b)

