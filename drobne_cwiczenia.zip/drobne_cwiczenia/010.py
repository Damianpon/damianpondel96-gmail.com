a = "Ala ma Asa"
b = a.upper()
c = a.lower()
print(b)
print(c)

