a = [3, 5, 7]
b = sum(a)
print(b)