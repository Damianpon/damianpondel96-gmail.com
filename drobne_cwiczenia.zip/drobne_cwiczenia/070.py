b = ";".join(['ala', 'bartek', 'czarek'])
print(b)
