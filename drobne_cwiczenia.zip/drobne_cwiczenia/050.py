a = [3, 5, 7]
b = a.reverse()
print(b)

