a = '.'.join(['a', 'b']).join(['a', 'b'])
print(a)
