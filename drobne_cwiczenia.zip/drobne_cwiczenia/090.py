c = ";".join(['ala', 'bartek', 'czarek']).upper()
print(c)
