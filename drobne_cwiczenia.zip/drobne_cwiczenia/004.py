print(2 * 2)
