a = ['ala', 'bartek', 'czarek']
b = ";".join(a)
print(b)
