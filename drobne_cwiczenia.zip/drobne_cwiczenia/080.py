a = ['ala', 'bartek', 'czarek']
b = ";".join(a)
c = b.upper()
print(c)
