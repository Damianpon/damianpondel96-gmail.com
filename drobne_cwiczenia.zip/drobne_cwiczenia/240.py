a = (2, 4)
print("%d do kwadratu to %d" % a)