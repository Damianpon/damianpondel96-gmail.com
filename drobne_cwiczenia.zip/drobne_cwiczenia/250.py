a = [2, 4]
print("%d do kwadratu to %d" % a)

# Wskazowka (zakodowana w ROT13):
# Bcrengbe jlcryavravn jmbepn (bcrengbe %) zn qbfgnp qjn nethzragl:
# - m yrjrw zn olp ancvf
# - m cenjrw zn olp xebgxn (ab, rjraghnyavr fybjavx - nyr ghgnw gb avr zn manpmravn)
# Nethzrag m cenjrw avr zbmr olp yvfgn.
