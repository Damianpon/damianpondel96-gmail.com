a = [3, 5, 7]
a.reverse()
print(a)

