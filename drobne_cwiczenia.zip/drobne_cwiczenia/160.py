a = "Ala ma Asa"
print(len(a))
