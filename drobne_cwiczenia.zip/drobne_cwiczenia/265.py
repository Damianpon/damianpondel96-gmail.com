a = [3, 5, 7]
for b in a:
	print(b)
