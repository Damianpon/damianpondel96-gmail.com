a = "Ala ma Asa"
a.upper()
print(a)
