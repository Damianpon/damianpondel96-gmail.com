text = "Programist\rJunior"
print(text)